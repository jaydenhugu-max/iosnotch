# Notch (Compose + overlay service)
Push this folder to a GitHub repo -> Actions tab -> "Build APK" -> download `IosNotch-debug-apk`.
Install, open the app, grant "Display over other apps", flip "Show notch".
