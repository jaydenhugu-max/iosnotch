package com.ioscam.notch

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NotchScreen()
                }
            }
        }
    }
}

private fun startNotch(ctx: Context) {
    ContextCompat.startForegroundService(ctx, Intent(ctx, NotchService::class.java))
}

private fun openOverlaySettings(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun fmt(v: Float): String = if (v % 1f == 0f) "${v.toInt()}" else "%.1f".format(v)

@Composable
fun NotchScreen() {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(NotchStore.load(ctx)) }
    var hasPerm by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) hasPerm = Settings.canDrawOverlays(ctx)
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(hasPerm) { if (hasPerm && cfg.enabled) startNotch(ctx) }

    val update: (NotchConfig) -> Unit = { n -> cfg = n; NotchStore.save(ctx, n) }

    val setEnabled: (Boolean) -> Unit = { on ->
        if (on && !hasPerm) {
            openOverlaySettings(ctx)
        } else {
            update(cfg.copy(enabled = on))
            if (on) startNotch(ctx) else ctx.stopService(Intent(ctx, NotchService::class.java))
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Notch", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        PhonePreview(cfg)

        if (!hasPerm) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Overlay permission needed", fontWeight = FontWeight.SemiBold)
                    Text("Allow \"Display over other apps\" so the notch can be drawn on top of everything.")
                    Button(onClick = { openOverlaySettings(ctx) }) { Text("Grant permission") }
                }
            }
        }

        ToggleRow("Show notch", "Draws the notch over every app", cfg.enabled && hasPerm, setEnabled)

        Text("Presets", fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NOTCH_PRESETS.forEach { p ->
                FilledTonalButton(
                    onClick = {
                        update(cfg.copy(widthDp = p.w, heightDp = p.h, bottomRadiusDp = p.br, flareDp = p.fr))
                    },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text(p.name, fontSize = 13.sp, maxLines = 1) }
            }
        }

        Text("Shape", fontWeight = FontWeight.SemiBold)
        SliderRow("Width (total, at top edge)", cfg.widthDp, 60f..340f) { update(cfg.copy(widthDp = it)) }
        SliderRow("Height", cfg.heightDp, 12f..60f) { update(cfg.copy(heightDp = it)) }
        SliderRow("Bottom corner radius", cfg.bottomRadiusDp, 0f..30f) { update(cfg.copy(bottomRadiusDp = it)) }
        SliderRow("Top blend (melt into bezel)", cfg.flareDp, 0f..20f) { update(cfg.copy(flareDp = it)) }

        ToggleRow("Speaker & camera", "Adds the dark speaker slot and lens", cfg.showSensors) {
            update(cfg.copy(showSensors = it))
        }
        ToggleRow("Rounded screen corners", "Four black corners like an iPhone", cfg.corners) {
            update(cfg.copy(corners = it))
        }
        if (cfg.corners) {
            SliderRow("Corner radius", cfg.cornerRadiusDp, 0f..60f) { update(cfg.copy(cornerRadiusDp = it)) }
        }
        ToggleRow("Start on boot", "Brings the notch back after a restart", cfg.startOnBoot) {
            update(cfg.copy(startOnBoot = it))
        }

        OutlinedButton(
            onClick = {
                val p = NOTCH_PRESETS[0]
                update(
                    cfg.copy(
                        widthDp = p.w, heightDp = p.h, bottomRadiusDp = p.br, flareDp = p.fr,
                        showSensors = true, corners = false, cornerRadiusDp = 36f
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Reset to iPhone X") }

        Text(
            "Xiaomi/MIUI tip: set this app to \"No restrictions\" under battery saver, enable Autostart, " +
                "and allow \"Display pop-up windows while running in background\" in the app's permissions " +
                "so the notch is not killed or hidden.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun PhonePreview(cfg: NotchConfig) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
            .background(Color.Black)
            .padding(start = 6.dp, end = 6.dp, top = 14.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFF6F96C8), Color(0xFFE6EAF2))))
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp),
                factory = { c -> NotchView(c).apply { topCornersOnly = true } },
                update = { it.config = cfg }
            )
        }
    }
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontSize = 14.sp)
            TextButton(
                onClick = { onChange((value - 0.5f).coerceIn(range)) },
                modifier = Modifier.size(40.dp),
                contentPadding = PaddingValues(0.dp)
            ) { Text("−", fontSize = 20.sp) }
            Text("${fmt(value)} dp", fontSize = 14.sp, fontWeight = FontWeight.Medium)
            TextButton(
                onClick = { onChange((value + 0.5f).coerceIn(range)) },
                modifier = Modifier.size(40.dp),
                contentPadding = PaddingValues(0.dp)
            ) { Text("+", fontSize = 20.sp) }
        }
        Slider(
            value = value,
            onValueChange = { onChange(((it * 2f).roundToInt() / 2f).coerceIn(range)) },
            valueRange = range
        )
    }
}
