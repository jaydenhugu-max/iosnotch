package com.ioscam.notch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Draws the notch as ONE vector path. Width only changes the length of the straight
 * top/bottom segments; the four arcs (two concave top flares, two convex bottom corners)
 * are fixed-radius arcs, so the edges never stretch or squash.
 */
class NotchView(context: Context) : View(context) {

    var config: NotchConfig = NotchConfig()
        set(value) { field = value; rebuild(); invalidate() }

    /** Preview mode: only draw the two top screen corners. */
    var topCornersOnly: Boolean = false
        set(value) { field = value; rebuild(); invalidate() }

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }
    private val speakerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF212125.toInt() }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF17181F.toInt() }
    private val lensPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A1230.toInt() }
    private val glintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A4A7A.toInt() }

    private val notchPath = Path()
    private val cornerPath = Path()
    private val speakerRect = RectF()
    private var camX = 0f
    private var camY = 0f
    private var camR = 0f
    private var hasSensors = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    private fun rebuild() {
        notchPath.reset()
        cornerPath.reset()
        val w = width.toFloat()
        val vh = height.toFloat()
        if (w <= 0f) return

        val c = config
        val cx = w / 2f
        val h = c.heightDp * d
        val fr = min(c.flareDp * d, h)
        val total = min(c.widthDp * d, w)
        val body = max(total - 2f * fr, 2f)
        val br = min(c.bottomRadiusDp * d, min(body / 2f, max(h - fr, 0f)))
        val outer = body + 2f * fr

        val left = cx - outer / 2f          // outer top-left point (on the screen edge)
        val bl = left + fr                  // body left edge
        val brx = bl + body                 // body right edge
        val right = brx + fr                // outer top-right point

        notchPath.moveTo(left, 0f)
        // concave flare, left (blends the notch into the top edge)
        notchPath.arcTo(RectF(left - fr, 0f, left + fr, 2f * fr), 270f, 90f)
        notchPath.lineTo(bl, h - br)
        // bottom-left convex corner
        notchPath.arcTo(RectF(bl, h - 2f * br, bl + 2f * br, h), 180f, -90f)
        notchPath.lineTo(brx - br, h)
        // bottom-right convex corner
        notchPath.arcTo(RectF(brx - 2f * br, h - 2f * br, brx, h), 90f, -90f)
        notchPath.lineTo(brx, fr)
        // concave flare, right
        notchPath.arcTo(RectF(right - fr, 0f, right + fr, 2f * fr), 180f, 90f)
        notchPath.close()

        // speaker + camera (proportions taken from the iPhone X reference)
        hasSensors = c.showSensors && body > 40f * d
        if (hasSensors) {
            val spW = body * 0.24f
            val spH = max(h * 0.23f, 3f * d)
            val cy = h * 0.32f
            speakerRect.set(cx - spW / 2f, cy - spH / 2f, cx + spW / 2f, cy + spH / 2f)
            camR = h * 0.19f
            camY = cy
            camX = min(cx + body * 0.22f, brx - br - camR)
        }

        // screen corners
        if (c.corners) {
            val r = c.cornerRadiusDp * d
            if (r > 0f) {
                cornerPath.moveTo(0f, 0f); cornerPath.lineTo(r, 0f)
                cornerPath.arcTo(RectF(0f, 0f, 2f * r, 2f * r), 270f, -90f); cornerPath.close()
                cornerPath.moveTo(w, 0f); cornerPath.lineTo(w - r, 0f)
                cornerPath.arcTo(RectF(w - 2f * r, 0f, w, 2f * r), 270f, 90f); cornerPath.close()
                if (!topCornersOnly && vh > 0f) {
                    cornerPath.moveTo(w, vh); cornerPath.lineTo(w, vh - r)
                    cornerPath.arcTo(RectF(w - 2f * r, vh - 2f * r, w, vh), 0f, 90f); cornerPath.close()
                    cornerPath.moveTo(0f, vh); cornerPath.lineTo(r, vh)
                    cornerPath.arcTo(RectF(0f, vh - 2f * r, 2f * r, vh), 90f, 90f); cornerPath.close()
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawPath(cornerPath, fill)
        canvas.drawPath(notchPath, fill)
        if (hasSensors) {
            canvas.drawRoundRect(speakerRect, speakerRect.height() / 2f, speakerRect.height() / 2f, speakerPaint)
            canvas.drawCircle(camX, camY, camR, ringPaint)
            canvas.drawCircle(camX, camY, camR * 0.62f, lensPaint)
            canvas.drawCircle(camX - camR * 0.2f, camY - camR * 0.2f, camR * 0.15f, glintPaint)
        }
    }
}
