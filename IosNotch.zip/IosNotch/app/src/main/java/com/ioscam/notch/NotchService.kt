package com.ioscam.notch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.ceil

class NotchService : Service() {

    private lateinit var wm: WindowManager
    private var view: NotchView? = null
    private var added = false

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyConfig() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = NotchView(this)
        NotchStore.prefs(this).registerOnSharedPreferenceChangeListener(listener)
        applyConfig()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyConfig()
    }

    private fun applyConfig() {
        val v = view ?: return
        val c = NotchStore.load(this)
        if (!c.enabled) {
            stopSelf()
            return
        }
        v.config = c
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        v.visibility = if (landscape) View.GONE else View.VISIBLE
        val lp = layoutParams(c)
        try {
            if (added) wm.updateViewLayout(v, lp) else { wm.addView(v, lp); added = true }
        } catch (e: Exception) {
            // overlay permission missing or window already gone
        }
    }

    private fun layoutParams(c: NotchConfig): WindowManager.LayoutParams {
        val density = resources.displayMetrics.density
        val height = if (c.corners) WindowManager.LayoutParams.MATCH_PARENT
        else ceil(c.heightDp * density).toInt().coerceAtLeast(1)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_INSET_NO_DECOR,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "notch"
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Notch overlay", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Notch overlay is running")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        NotchStore.prefs(this).unregisterOnSharedPreferenceChangeListener(listener)
        val v = view
        if (v != null && added) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        added = false
        view = null
        super.onDestroy()
    }
}
