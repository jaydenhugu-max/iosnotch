package com.ioscam.notch

import android.content.Context
import android.content.SharedPreferences

/**
 * All sizes are in dp.
 * widthDp is the TOTAL width at the very top edge (flares included), so changing the
 * flare radius never changes the overall footprint of the notch.
 */
data class NotchConfig(
    val enabled: Boolean = false,
    val widthDp: Float = 217f,
    val heightDp: Float = 29f,
    val bottomRadiusDp: Float = 17f,
    val flareDp: Float = 8f,
    val showSensors: Boolean = true,
    val corners: Boolean = false,
    val cornerRadiusDp: Float = 36f,
    val startOnBoot: Boolean = true
)

data class NotchPreset(val name: String, val w: Float, val h: Float, val br: Float, val fr: Float)

val NOTCH_PRESETS = listOf(
    NotchPreset("iPhone X", 217f, 29f, 17f, 8f),
    NotchPreset("iPhone 12", 209f, 31f, 18f, 8f),
    NotchPreset("iPhone 13", 166f, 31f, 18f, 9f)
)

object NotchStore {
    private const val FILE = "notch_prefs"

    fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(ctx: Context): NotchConfig {
        val p = prefs(ctx)
        val d = NotchConfig()
        return NotchConfig(
            enabled = p.getBoolean("enabled", d.enabled),
            widthDp = p.getFloat("widthDp", d.widthDp),
            heightDp = p.getFloat("heightDp", d.heightDp),
            bottomRadiusDp = p.getFloat("bottomRadiusDp", d.bottomRadiusDp),
            flareDp = p.getFloat("flareDp", d.flareDp),
            showSensors = p.getBoolean("showSensors", d.showSensors),
            corners = p.getBoolean("corners", d.corners),
            cornerRadiusDp = p.getFloat("cornerRadiusDp", d.cornerRadiusDp),
            startOnBoot = p.getBoolean("startOnBoot", d.startOnBoot)
        )
    }

    fun save(ctx: Context, c: NotchConfig) {
        prefs(ctx).edit()
            .putBoolean("enabled", c.enabled)
            .putFloat("widthDp", c.widthDp)
            .putFloat("heightDp", c.heightDp)
            .putFloat("bottomRadiusDp", c.bottomRadiusDp)
            .putFloat("flareDp", c.flareDp)
            .putBoolean("showSensors", c.showSensors)
            .putBoolean("corners", c.corners)
            .putFloat("cornerRadiusDp", c.cornerRadiusDp)
            .putBoolean("startOnBoot", c.startOnBoot)
            .apply()
    }
}
