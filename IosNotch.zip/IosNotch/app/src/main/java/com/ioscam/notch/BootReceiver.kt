package com.ioscam.notch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val c = NotchStore.load(context)
        if (c.enabled && c.startOnBoot && Settings.canDrawOverlays(context)) {
            ContextCompat.startForegroundService(context, Intent(context, NotchService::class.java))
        }
    }
}
